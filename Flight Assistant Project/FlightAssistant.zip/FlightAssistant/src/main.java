 import java.util.Scanner;  // needed for Scanner

 import java.util.*;
 
 import javax.swing.*; //popup window

 /** Class LinearProbingHashTable **/
 class LinearProbingHashTable
 {
     private int currentSize, maxSize;       
     private String[] keys;   
     private String[] vals;    
  
     /** Constructor **/
     public LinearProbingHashTable(int capacity) 
     {
         currentSize = 0;
         maxSize = capacity;
         keys = new String[maxSize];
         vals = new String[maxSize];
     }  
  
     /** Function to clear hash table **/
     public void makeEmpty()
     {
         currentSize = 0;
         keys = new String[maxSize];
         vals = new String[maxSize];
     }
  
     /** Function to get size of hash table **/
     public int getSize() 
     {
         return currentSize;
     }
  
     /** Function to check if hash table is full **/
     public boolean isFull() 
     {
         return currentSize == maxSize;
     }
  
     /** Function to check if hash table is empty **/
     public boolean isEmpty() 
     {
         return getSize() == 0;
     }
  
     /** Fucntion to check if hash table contains a key **/
     public boolean contains(String key) 
     {
         return get(key) !=  null;
     }
  
     /** Functiont to get hash code of a given key **/
     private int hash(String key) 
     {
         return key.hashCode() % maxSize;
     }    
  
     /** Function to insert key-value pair **/
     public void insert(String key, String val) 
     {                
         int tmp = hash(key);
         int i = tmp;
         do
         {
             if (keys[i] == null)
             {
                 keys[i] = key;
                 vals[i] = val;
                 currentSize++;
                 return;
             }
             if (keys[i].equals(key)) 
             { 
                 vals[i] = val; 
                 return; 
             }            
             i = (i + 1) % maxSize;            
         } while (i != tmp);       
     }
  
     /** Function to get value for a given key **/
     public String get(String key) 
     {
         int i = hash(key);
         while (keys[i] != null)
         {
             if (keys[i].equals(key))
                 return vals[i];
             i = (i + 1) % maxSize;
         }            
         return null;
     }
  
     /** Function to remove key and its value **/
     public void remove(String key) 
     {
         if (!contains(key)) 
             return;
  
         /** find position key and delete **/
         int i = hash(key);
         while (!key.equals(keys[i])) 
             i = (i + 1) % maxSize;        
         keys[i] = vals[i] = null;
  
         /** rehash all keys **/        
         for (i = (i + 1) % maxSize; keys[i] != null; i = (i + 1) % maxSize)
         {
             String tmp1 = keys[i], tmp2 = vals[i];
             keys[i] = vals[i] = null;
             currentSize--;  
             insert(tmp1, tmp2);            
         }
         currentSize--;        
     }       
  
     /** Function to print HashTable **/
     public void printHashTable()
     {
         System.out.println("\nHash Table: ");
         for (int i = 0; i < maxSize; i++)
             if (keys[i] != null)
                 System.out.println(keys[i] +" "+ vals[i]);
         System.out.println();
     }   

 }

 
public class main {
	public static void main(String[] args) {
		KMP_String_Matching KMP = new KMP_String_Matching();
		
		String character, character1;
		StringBuffer s = new StringBuffer("");
		StringBuffer s1 = new StringBuffer("");
		int[] sum = new int[5]; //save 5 airports in the array
		int[] t=new int[25];
		
		System.out.println("Please choose one airport for departure");
		
		// Create a single shared Scanner for keyboard input
        Scanner scanner = new Scanner( System.in );
        
        // Read a line of text from the user.
        String input = scanner.nextLine();

        // Display the input back to the user.
        System.out.println(input);
              
        character = input;
        s1 = s1.append(character);  //name, string Buffer
		
		switch(character) {
		case "MKE": 	//character = "MKE";
			int a = (int)'M';
			int b = (int)'K';
			int c = (int)'E';
			//System.out.println(a);
			sum[0] = a*10000+b*100+c;
			System.out.println(sum[0]);
			s = s.append(sum[0]);			
			//System.out.println(s);
			break;
		case "ORD": 
			int a0 = (int)'O';
			int b0 = (int)'R';
			int c0 = (int)'D';
			//System.out.println(a);
			sum[1] = a0*10000+b0*100+c0;
			System.out.println(sum[1]);
			s = s.append(sum[1]);
			break;
		case "SEA":
			int a1 = (int)'S';
			int b1 = (int)'E';
			int c1 = (int)'A';
			//System.out.println(a);
			sum[2] = a1*10000+b1*100+c1;
			System.out.println(sum[2]);
			s = s.append(sum[2]);
			break;
		case "SFO":
			int a2 = (int)'S';
			int b2 = (int)'F';
			int c2 = (int)'O';
			//System.out.println(a);
			sum[3] = a2*10000+b2*100+c2;
			System.out.println(sum[3]);
			s = s.append(sum[3]);
			break;
		case "LAX":
			int a3 = (int)'L';
			int b3 = (int)'A';
			int c3 = (int)'X';
			//System.out.println(a);
			sum[4] = a3*10000+b3*100+c3;
			System.out.println(sum[4]);
			s = s.append(sum[4]);
			break;
		default:
			//nothing here
			break;
		}
		
		//next for destination
        System.out.println("Please choose one airport for destination");
		
		// Create a single shared Scanner for keyboard input
        Scanner scanner1 = new Scanner( System.in );
        
        // Read a line of text from the user.
        String input1 = scanner1.nextLine();

        // Display the input back to the user.
        System.out.println(input1);
		
        character1 = input1;
        s1 = s1.append(character1);
        String str01 = s1.toString();
        System.out.println(str01);
		
		switch(character1) {
		case "MKE": 	//character = "MKE";
			int a = (int)'M';
			int b = (int)'K';
			int c = (int)'E';
			//System.out.println(a);
			sum[0] = a*10000+b*100+c;
			//System.out.println(sum[0]);
			s = s.append(sum[0]);
			//System.out.println(s);
			String str0 = s.toString();
			long num0 = Long.parseLong(str0);
			System.out.println(str0);
			
			break;
		case "ORD": 
			int a0 = (int)'O';
			int b0 = (int)'R';
			int c0 = (int)'D';
			//System.out.println(a);
			sum[1] = a0*10000+b0*100+c0;
			//System.out.println(sum[1]);
			s = s.append(sum[1]);
			//System.out.println(s);
			String str1 = s.toString();
			long num1 = Long.parseLong(str1);
			System.out.println(str1);
			break;
		case "SEA":
			int a1 = (int)'S';
			int b1 = (int)'E';
			int c1 = (int)'A';
			//System.out.println(a);
			sum[2] = a1*10000+b1*100+c1;
			//System.out.println(sum[2]);
			s = s.append(sum[2]);
			//System.out.println(s);
			String str2 = s.toString();
			long num2 = Long.parseLong(str2);
			System.out.println(str2);
			break;
		case "SFO":
			int a2 = (int)'S';
			int b2 = (int)'F';
			int c2 = (int)'O';
			//System.out.println(a);
			sum[3] = a2*10000+b2*100+c2;
			//System.out.println(sum[3]);
			s = s.append(sum[3]);
			//System.out.println(s);
			String str3 = s.toString();
			long num3 = Long.parseLong(str3);
			System.out.println(str3);
			break;
		case "LAX":
			int a3 = (int)'L';
			int b3 = (int)'A';
			int c3 = (int)'X';
			//System.out.println(a);
			sum[4] = a3*10000+b3*100+c3;
			//System.out.println(sum[4]);
			s = s.append(sum[4]);
			//System.out.println(s);
			String str4 = s.toString();
			long num4 = Long.parseLong(str4);
			System.out.println(str4);
			break;
		
		default:
			//nothing here
			break;
		}
        
        //previous steps will lead us get 12-digit integer
		//we can use it to detect in hash table
        
		System.out.println("");
		
		//s1 for two airports' names
		//s for 12-digit number
		
		// create a hash table for 25 integers
		// string for key and values
		Hashtable<String,String> ht=new Hashtable<String,String>();  
		 
		//MKE - 777569
		ht.put("777569777569","invalid");     // - MKE 
		ht.put("777569798268","05:25-06:23AA189,"+
               "08:25-09:19UA189,"+
               "09:30-10:24UA189,"+
               "10:07-11:06AA260,"+
               "13:15-14:31DA234,"+
               "16:05-17:05AA265");  		// - ORD
		ht.put("777569836965","07:50-10:34DA195,"+
				"08:30-11:10UA203,"+
				"09:03-12:52DA299,"+
				"05:25-10:00AA299,"+
				"09:29-12:47UA301,"+
				"12:30-14:58AA342,"+
				"14:27-17:03UA356,"+
				"15:10-18:42DA351");  				// - SEA
		ht.put("777569837079","07:18-10:42UA267,"+
				"08:25-11:36UA288,"+
				"09:10-12:00UA300,"+
				"12:18-15:05AA321,"+
				"16:04-19:00DA299"); 				// - SFO
		ht.put("777569766588","08:25-11:01UA147,"+
				"08:45-11:28UA188,"+
				"12:07-15:35DA208,"+
				"17:05-20:27DA214");				// - LAX
		
		//ORD - 798268
		ht.put("798268777569","10:25-11:10UA189,"+
				"11:40-12:25UA189,"+
				"08:00-08:53UA166,"+
				"14:54-15:40AA201,"+
				"08:40-09:28AA178,"+
				"15:50-16:40UA177,"+
				"16:25-17:10DA231,"+
				"17:03-18:00UA203,"+
				"20:00-20:54AA258,"+
				"21:06-22:00AA177");     // - MKE 
		ht.put("798268798268","invalid");  		// - ORD
		ht.put("798268836965","07:00-09:33DA198,"+
				"07:30-10:00AA201," +
				"07:45-10:12UA207," +
				"10:30-13:00AA231," +
				"13:15-15:43UA266," +
				"14:25-17:05DA289," +
				"17:52-20:32DA254," +
				"10:20-12:47UA239");  				// - SEA
		ht.put("798268837079","10:25-13:09AA109," +
				"11:45-14:27UA147," +
				"15:45-18:27UA166," +
				"06:45-09:22UA201," +
				"20:05-22:50UA189," +
				"07:20-10:04AA279," +
				"08:20-11:00UA279,"+
				"10:00-12:42UA286,"+
				"12:50-15:27UA301"); 				// - SFO
		ht.put("798268766588","06:45-09:20UA098,"+
				"07:56-10:34UA098,"+
				"09:15-11:55UA109,"+
				"11:35-14:02UA109,"+
				"14:02-16:32UA114,"+
				"21:08-23:37UA103,"+
				"07:22-10:10AA102,"+
				"09:00-11:50AA105,"+
				"09:46-12:20AA134,"+
				"13:25-15:28AA156,"+
				"15:12-17:40AA177,"+
				"19:31-21:55UA175,"+
				"18:25-21:08AA175");				// - LAX
				
		//SEA - 836965
		ht.put("836965777569","12:15-18:13AA229,"+
                       "12:25-21:08DA299,"+
                        "07:00-13:40AA277,"+
                        "13:00-19:03UA289");     // - MKE 
		ht.put("836965798268","06:50-12:48UA196,"+
				"07:00-13:06AA201,"+
				"07:40-13:50DA237,"+
				"11:07-17:07UA245,"+
				"11:15-17:17DA278,"+
				"11:15-17:35AA267,"+
				"13:57-20:07UA238,"+
				"17:51-23:55DA256,"+
				"11:25-17:27UA278");  		// - ORD

		ht.put("836965836965","invalid");  				// - SEA
		ht.put("836965837079","05:35-07:42UA201,"+
				"06:15-08:15AA205,"+
				"17:15-19:27DA211,"+
				"07:40-10:05DA236,"+
				"13:26-15:43DA251,"+
				"15:54-18:04UA249,"+
				"17:05-19:16UA277,"+
				"20:45-23:10DA269"); 				// - SFO
		ht.put("836965766588","06:00-08:40DA177,"+
				"06:00-09:04AA182,"+
				"08:00-10:45DA189,"+
				"10:30-13:20AA201,"+
				"12:06-14:59UA218,"+
				"13:22-16:12AA236,"+
				"17:36-20:30AA251,"+
				"20:16-22:10AA234");				// - LAX

				
		//SFO - 837079
		ht.put("837079777569","06:30-14:15DA297,"+
				"11:00-18:48DA278,"+
				"13:15-19:43UA285,"+
				"12:25-18:21DA273,"+
				"12:59-19:02DA271");     // - MKE 

		ht.put("837079798268","05:20-11:43UA114,"+
				"08:00-14:22AA121,"+
				"12:30-18:51AA131,"+
				"08:15-14:30UA279,"+
				"09:25-15:30UA276,"+
				"09:40-15:55UA288,"+
				"10:40-17:03UA302,"+
				"11:00-17:58AA294,"+
				"12:10-18:33UA273,"+
				"14:15-20:47AA276,"+
				"14:19-20:41UA282");  		// - ORD
		ht.put("837079836965","16:13-18:19DA201,"+
				"10:50-12:56UA201,"+
				"21:47-23:45AA177,"+
				"08:05-10:28DA205,"+
				"10:35-12:22DA211,"+
				"06:46-08:58DA199,"+
				"11:02-13:18UA226,"+
				"10:35-12:46DA225,"+
				"12:25-14:40DA247,"+
				"14:15-16:25DA261,"+
				"17:37-19:44UA253,"+
				"06:20-08:35UA201,"+
				"08:11-10:27UA279,"+
				"18:05-20:12DA238");  				// - SEA
		ht.put("837079837079","invalid"); 				// - SFO
		ht.put("837079766588","06:00-07:32UA045,"+
				"16:15-17:50UA045,"+
				"20:10-21:45UA078,"+
				"20:50-10:25UA064,"+
				"22:40-00:11UA099,"+
				"06:53-08:37UA102,"+
				"09:20-11:03UA109,"+
				"09:37-11:19UA121,"+
				"05:40-07:06AA099,"+
				"07:00-08:51AA079,"+
				"07:45-08:51DA059,"+
				"08:40-10:36AA059");				// - LAX

				
		//LAX - 766588
		ht.put("766588777569","12:45-18:08DA147,"+
				"06:30-12:15DA147,"+
				"07:30-13:22DA186,"+
				"15:11-21:15UA201,"+
				"15:50-22:15DA189");     // - MKE 
		ht.put("766588798268","05:37-11:39UA098,"+
				"16:50-22:54UA098,"+
				"13:15-19:30AA108,"+
				"12:46-18:52UA175,"+
				"06:45-12:43UA162,"+
				"07:15-13:28AA157,"+
				"08:20-14:27UA179,"+
				"10:40-16:50UA183,"+
				"11:16-17:40AA201,"+
				"11:50-18:10DA232,"+
				"14:02-20:13UA241,"+
				"15:11-21:25UA207,"+
				"09:40-15:59AA253");  		// - ORD
		ht.put("766588836965","06:05-08:54DA177,"+
				"07:00-09:58AA177,"+
				"08:00-10:55DA182,"+
				"09:50-12:52AA201,"+
				"14:10-17:05AA226,"+
				"15:25-18:29UA206,"+
				"16:46-19:46AA219,"+
				"20:42-23:22AA186,"+
				"10:05-12:52AA173,"+
				"11:05-13:50AA185,"+
				"13:55-16:34DA205,"+
				"08:25-11:29UA1063");  				// - SEA
		ht.put("766588837079","06:06-07:31UA045,"+
				"14:30-16:00UA045,"+
				"15:22-16:52UA068,"+
				"16:27-17:57UA070,"+
				"20:00-21:30UA099,"+
				"13:25-15:05UA107,"+
				"07:00-08:35DA067,"+
				"10:00-11.39DA079,"+
				"11:46-13:13DA081,"+
				"12:30-14:02AA106,"+
				"13:30-15:05DA111,"+
				"14:00-15:34AA128,"+
				"15:30-17:05DA100,"+
				"17:00-18:30DA095"); 				// - SFO
		ht.put("766588766588","invalid");				// - LAX		
		
		//test for output
		//System.out.println(ht);
		
		//find information for specific index
		String keyString = s.toString(); //index
		
		Set values = new HashSet();
		
		for(Map.Entry entry: ht.entrySet()){
            if(keyString.equals(entry.getKey())){
                values.add(entry.getValue()); //no break, looping entire hashtable
            }
        }

		System.out.println(keyString + " " + values);
		
		//get rid of square brackets 
		String text = values.toString().replaceAll("(^\\[|\\]$)", "");
		System.out.println(text);
		
		// sort algorithm based on price
		// get the number for ','
		int count = text.length() - text.replace(",", "").length();
		count += 1;
		
		int fixed = 17;
		int price;
		char p, q, o;
		int[] priceArray = new int[count];
		for (int i = 0; i<count; i++) {
			p = text.charAt(13 + i*fixed);  // + text.charAt(17 + i*fixed) + text.charAt(18 + i*fixed);
			int p1 = Character.getNumericValue(p)*100;
			
			q = text.charAt(14 + i*fixed); 
			int q1 = Character.getNumericValue(q)*10;
			
			o = text.charAt(15 + i*fixed); 
			int o1 = Character.getNumericValue(o)*1;
			
			price = p1 + q1 + o1;
			
			priceArray[i] = price;
			//System.out.println(priceArray[i]);
			//System.out.println(p);
		}
		
		/** price is a integer
		int sss = priceArray[2] - priceArray[1];
		System.out.println(sss);
		**/
		
		//int arr[] = {10, 7, 8, 9, 1, 5};
        int n = priceArray.length;
 
        QuickSort ob = new QuickSort();
        ob.sort(priceArray, 0, n-1);
        
        //print out sort list for tickets
        System.out.println("sorted result based on price");
        for (int i = 0; i < n; i++) {
        	System.out.println(priceArray[i]);
        }
        
        //convert number to string
        String output = Integer.toString(priceArray[0]);
        //System.out.println(output);
        
        
        System.out.println("Information about our cheapest ticket:");
        // find from output
        String txt = text;
		String pat = output;
		KMP.KMPSearch(pat,txt);	//KMP algorithm will search for all information
		
        System.out.println("");
        
        
        long startTime = System.currentTimeMillis();

        long total = 0;
        for (int i = 0; i < 10000000; i++) {
           total += i;
        }

        long stopTime = System.currentTimeMillis();
        long elapsedTime = stopTime - startTime;
        System.out.println(elapsedTime);
 
	}
	
}

